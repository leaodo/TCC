import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teste-ar',
  templateUrl: './teste-ar.page.html',
  styleUrls: ['./teste-ar.page.scss'],
  standalone:false
})
export class TesteARPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
